import { Component, OnInit } from '@angular/core';
import {AuthService} from '../service/auth.service';
import {ActivatedRoute, Router} from '@angular/router';



@Component({
  selector: 'app-mainpage',
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css']
})
export class MainpageComponent implements OnInit {

  myRegister=false;

  constructor(private auth: AuthService, private route: ActivatedRoute, private router: Router) {
  }


  class="btn btn-lg btn-apple"


  ngOnInit(): void {
    this.myRegister = this.auth.isUserLoggedIn();
    window.addEventListener('storage', (event) => {
      if (event.storageArea === localStorage) {
        const token = localStorage.getItem(this.auth.USER_NAME_SESSION_ATTRIBUTE_NAME);
        if (token === undefined) {
          this.handleLogout();
        }
      }
    }, false);
  }

  handleLogout() {
    this.myRegister = false;
    this.auth.logout();
  }

  gotoHomePage() {
    this.router.navigate(['/']);
  }
}
