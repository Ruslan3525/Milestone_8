import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Quiz } from './quiz.model';

@Injectable()
export class QuizService {

  private url: string;

  constructor(private http: HttpClient) {
    this.url = 'http://localhost:8080/quiz';
  }
  public findAll(): Observable<Quiz[]> {
    return this.http.get<Quiz[]>(this.url);
  }
   public save(quiz: Quiz) {
    return this.http.post<Quiz[]>(this.url, quiz);
  }

}
