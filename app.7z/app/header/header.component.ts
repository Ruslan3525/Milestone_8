import {Component, OnInit} from '@angular/core';
import {AuthService} from '../service/auth.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isLoggedIn = false;

  constructor(private auth: AuthService, private route: ActivatedRoute, private router: Router) {
  }


  ngOnInit(): void {
    this.isLoggedIn = this.auth.isUserLoggedIn();
    window.addEventListener('storage', (event) => {
      if (event.storageArea === localStorage) {
        const token = localStorage.getItem(this.auth.USER_NAME_SESSION_ATTRIBUTE_NAME);
        if (token === undefined) {
          this.handleLogout();
        }
      }
    }, false);
  }

  // tslint:disable-next-line:typedef
  handleLogout() {
    this.isLoggedIn = false;
    this.auth.logout();
  }

  // tslint:disable-next-line:typedef
  gotoHomePage() {
    this.router.navigate(['/']);
  }
}
