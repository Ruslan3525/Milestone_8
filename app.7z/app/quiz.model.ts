export class Quiz {
  id: string;
  questions: string;
  answers1: { option: string, correct: boolean} [];
  answers2: string;
  answers3: string;
  correct: string;
}
