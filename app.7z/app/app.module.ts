import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { QwertyComponent } from './qwerty/qwerty.component';
import { LoginComponent } from './login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import { HomeComponent } from './home/home.component';
import { UsersComponent } from './users/users.component';
import { UserService } from './user-service.service';
import {FormsModule} from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { QuizComponent } from './quiz/quiz.component';
import { BackgroundDirective } from './background.directive';
import {HeaderComponent} from './header/header.component';
import { QuizService } from './quiz.service';
import { DialogComponent } from './dialog/dialog.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MainpageComponent } from './mainpage/mainpage.component';

const routes: Routes = [{ path: '', component: MainpageComponent},
{path: 'login' , component: LoginComponent},
{path: 'register' , component: RegisterComponent},
{
  path: 'users', component: UsersComponent
},
{
  path: 'home', component: HomeComponent
},
{
  path: 'quiz', component: QuizComponent
},
  {
    path: 'dialog', component: DialogComponent
  },
  {
    path: 'qwerty', component: QwertyComponent
  },
];

@NgModule({
  declarations: [
    AppComponent,
    QwertyComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    UsersComponent,
    QuizComponent,
    BackgroundDirective,
    HeaderComponent,
    DialogComponent,
    MainpageComponent

  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    FlexLayoutModule,
    MatButtonModule,
    MatToolbarModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatDialogModule
  ],
  entryComponents: [
    DialogComponent,
  ],
  providers: [UserService, QuizService, ],
  bootstrap: [AppComponent]
})
export class AppModule {
 
 }
