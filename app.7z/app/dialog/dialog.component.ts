import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {
  constructor(public matDialog: MatDialog){}
    openDialog() {
  const dialogConfig = new MatDialogConfig();
  this.matDialog.open(DialogComponent, dialogConfig);
    }
  ngOnInit(): void {
  }

}

