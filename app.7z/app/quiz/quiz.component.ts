import { Component, Inject, InjectionToken, OnInit } from '@angular/core';
import { Quiz } from '../quiz.model';
import {QuizService} from '../quiz.service';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
option: string;
answerSelected = false;
correctAnswers = 0;
incorrectAnswers = 0;
indexOfAnswer = -1;
currentQuiz = 0;
randomize: number;
num = 0;
id: number;
resultt = false;
  constructor(private service: QuizService){}
  quiz: Quiz[];
  ngOnInit(): void {
    this.service.findAll().subscribe(result => {
      this.quiz = result;
    });
  }
  onAnswer(index: number) {
   this.indexOfAnswer = index;
}

    checkAnswer(): void{
    if(this.indexOfAnswer > -1){
      //this.option = this.quiz[this.num].answers1[this.indexOfAnswer];
      if(this.option){
       this.correctAnswers++;
      } else
      {
        this.incorrectAnswers++;
      }
    }
    else {
      alert('Option is not chosen');
      return;
    }


  this.nextQuestion();

  }

  nextQuestion(){
    this.num++;
    this.currentQuiz++;
    this.answerSelected = false;
    this.indexOfAnswer = -1;

  }
  prevQuestion(){
  this.currentQuiz--;
  this.num--;
  }
showResult(){
  this.resultt = true;
}
}

